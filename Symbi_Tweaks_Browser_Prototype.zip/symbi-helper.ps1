# Symbi Tweaks local helper
# Fixed allow-list only: the browser cannot send arbitrary PowerShell commands.
$ErrorActionPreference = "Stop"
$Port = 18765

function Send-Json($ctx, $obj) {
    $bytes = [Text.Encoding]::UTF8.GetBytes(($obj | ConvertTo-Json -Compress))
    $ctx.Response.ContentType = "application/json"
    $ctx.Response.StatusCode = 200
    $ctx.Response.OutputStream.Write($bytes,0,$bytes.Length)
    $ctx.Response.Close()
}

function Backup-State {
    $dir="$env:ProgramData\SymbiTweaks"
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
    try { powercfg /getactivescheme | Out-File "$dir\power.txt" -Encoding utf8 } catch {}
    try {
        $gm=(Get-ItemProperty -Path "HKCU:\Software\Microsoft\GameBar" -Name AllowAutoGameMode -ErrorAction SilentlyContinue).AllowAutoGameMode
        "$gm" | Out-File "$dir\gamemode.txt" -Encoding utf8
    } catch {}
}

function Action($a) {
    switch ($a) {
      "performance" {
        Backup-State
        # Safer performance action: disable power throttling for current user.
        New-Item -Path "HKCU:\System\GameConfigStore" -Force | Out-Null
        Set-ItemProperty -Path "HKCU:\System\GameConfigStore" -Name GameDVR_Enabled -Type DWord -Value 0
        return "Performance setting applied."
      }
      "restore_performance" {
        Remove-ItemProperty -Path "HKCU:\System\GameConfigStore" -Name GameDVR_Enabled -ErrorAction SilentlyContinue
        return "Performance setting restored."
      }
      "game_mode_on" {
        New-Item -Path "HKCU:\Software\Microsoft\GameBar" -Force | Out-Null
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\GameBar" -Name AllowAutoGameMode -Type DWord -Value 1
        return "Game Mode preference enabled."
      }
      "game_mode_off" {
        New-Item -Path "HKCU:\Software\Microsoft\GameBar" -Force | Out-Null
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\GameBar" -Name AllowAutoGameMode -Type DWord -Value 0
        return "Game Mode preference disabled."
      }
      "high_performance" {
        powercfg /setactive SCHEME_MIN
        return "High Performance power plan selected."
      }
      "balanced" {
        powercfg /setactive SCHEME_BALANCED
        return "Balanced power plan selected."
      }
      "temp_cleanup" {
        $paths=@($env:TEMP,"$env:WINDIR\Temp")
        $count=0
        foreach($p in $paths){
          if(Test-Path $p){
            Get-ChildItem -LiteralPath $p -Force -ErrorAction SilentlyContinue |
              Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
            $count++
          }
        }
        return "Temporary-file cleanup completed."
      }
      "flush_dns" {
        ipconfig /flushdns | Out-Null
        return "DNS cache flushed."
      }
      "network_info" {
        $x=(Get-NetIPConfiguration | Select-Object InterfaceAlias,IPv4Address,DNSServer | Out-String).Trim()
        return $x
      }
      "startup" {
        Start-Process "ms-settings:startupapps"
        return "Opened Windows Startup Apps."
      }
      "system_info" {
        $os=Get-CimInstance Win32_OperatingSystem
        $cpu=(Get-CimInstance Win32_Processor | Select-Object -First 1).Name
        $ram=[math]::Round($os.TotalVisibleMemorySize/1MB,1)
        return "Windows: $($os.Caption) | CPU: $cpu | RAM: ${ram} GB"
      }
      "restore_all" {
        Remove-ItemProperty -Path "HKCU:\System\GameConfigStore" -Name GameDVR_Enabled -ErrorAction SilentlyContinue
        Remove-ItemProperty -Path "HKCU:\Software\Microsoft\GameBar" -Name AllowAutoGameMode -ErrorAction SilentlyContinue
        powercfg /setactive SCHEME_BALANCED
        return "Tracked Symbi settings restored to defaults/Balanced."
      }
      default { throw "Unknown action." }
    }
}

$listener = [Net.HttpListener]::new()
$listener.Prefixes.Add("http://127.0.0.1:$Port/")
$listener.Start()
Write-Host "Symbi Tweaks helper running on http://127.0.0.1:$Port/"
Write-Host "Close this window to stop it."

while($listener.IsListening){
  try{
    $ctx=$listener.GetContext()
    if($ctx.Request.HttpMethod -eq "OPTIONS"){
      $ctx.Response.Headers.Add("Access-Control-Allow-Origin","*")
      $ctx.Response.Headers.Add("Access-Control-Allow-Methods","GET,POST,OPTIONS")
      $ctx.Response.Headers.Add("Access-Control-Allow-Headers","Content-Type")
      $ctx.Response.StatusCode=204;$ctx.Response.Close();continue
    }
    $ctx.Response.Headers.Add("Access-Control-Allow-Origin","*")
    if($ctx.Request.HttpMethod -eq "GET" -and $ctx.Request.Url.AbsolutePath -eq "/status"){
      Send-Json $ctx @{ok=$true;message="Symbi helper connected."};continue
    }
    if($ctx.Request.HttpMethod -eq "POST" -and $ctx.Request.Url.AbsolutePath -eq "/action"){
      $reader=[IO.StreamReader]::new($ctx.Request.InputStream)
      $body=$reader.ReadToEnd();$reader.Close()
      $data=$body | ConvertFrom-Json
      try { Send-Json $ctx @{ok=$true;message=(Action $data.action)} }
      catch { Send-Json $ctx @{ok=$false;error=$_.Exception.Message} }
      continue
    }
    $ctx.Response.StatusCode=404;$ctx.Response.Close()
  }catch{}
}
