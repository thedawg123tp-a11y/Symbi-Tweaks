# Symbi Tweaks — Browser Prototype

## Run it
1. Keep `symbi-tweaks.html` and `symbi-helper.ps1` in the same folder.
2. Double-click `run-helper.bat` and allow the Windows permission prompt if needed.
3. Open `symbi-tweaks.html` in Chrome/Edge.
4. The dashboard should say **Helper connected**.
5. Use the buttons to run the supported actions.

## What is real
- Game Mode preference
- High Performance / Balanced power plan
- Temp cleanup
- DNS flush
- Windows Startup Apps page
- Basic system information
- Restore of Symbi-tracked settings

The helper deliberately uses a fixed action allow-list. The webpage cannot send arbitrary PowerShell commands.

## Important
This is a prototype. Some settings can require administrator privileges, and Windows versions can behave differently. Review a tweak before applying it.
