@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0symbi-helper.ps1"
pause
